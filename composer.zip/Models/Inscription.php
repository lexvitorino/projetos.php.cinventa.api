<?php

namespace Models;

use Exception;
use \Core\Model;
use \Models\File;

class Inscription extends Model
{
    private $subscriberId;
    private $result;

    public function __construct(int $subscriberId)
    {
        parent::__construct();

        $this->subscriberId = $subscriberId;
        $this->result = array(
            'message' => array(
                'hasError' => false,
                'errors' => array()
            ),
            'data' => array()
        );
    }

    public function get(string $evento)
    {
        try {
            $sql = "SELECT * 
                    FROM   inscriptions
                    WHERE  evento = :evento";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':evento', $evento);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                return $this->result = $sql->fetchAll();
            } else {
                return null;
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function getById(int $id): bool
    {
        try {
            $sql = "SELECT * 
                    FROM   Inscriptions
                    WHERE  id = :id";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':id', $id);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                $this->result['data'] = $sql->fetchAll();
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function getByDataAndEmail(int $id, string $data, string $email): bool
    {
        try {
            $sql = "SELECT * 
                    FROM   Inscriptions
                    WHERE  id <> :id
                    AND    data = :data
                    AND    email = :email";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':id', $id);
            $sql->bindValue(':data', $data);
            $sql->bindValue(':email', $email);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                $this->result['data'] = $sql->fetch();
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function getByEventoAndDataAndEmail(string $evento, string $data, string $email): bool
    {
        try {
            $sql = "SELECT * 
                    FROM   Inscriptions
                    WHERE  evento = :evento
                    AND    data = :data
                    AND    email = :email";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':evento', $evento);
            $sql->bindValue(':data', $data);
            $sql->bindValue(':email', $email);
            $sql->execute();

            if ($sql->rowCount() > 0) {
                $this->result['data'] = $sql->fetch();
                return true;
            } else {
                return false;
            }
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function confirmar(int $id): bool
    {
        try {
            $sql = "UPDATE Inscriptions
                    SET    confirmado = 1
                    WHERE  id = :id";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':id', $id);
            $sql->execute();

            if (!$this->getById($id)) {
                return false;
            }

            return true;
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function delete(int $id, $data): bool
    {
        return false;
    }

    public function update(int $id, $data): bool
    {
        return false;
    }

    public function create($data): bool
    {
        try {
            if (!$this->isValid($data)) {
                return false;
            }

            $sql = "INSERT INTO Inscriptions
                    (evento, data, email, nome, sobrenome, area, supervisor, lider)
                    VALUES 
                    (:evento, :data, :email, :nome, :sobrenome, :area, :supervisor, :lider)";

            $sql = $this->db->prepare($sql);
            $sql->bindValue(':evento', $data['evento']);
            $sql->bindValue(':email', $data['email']);
            $sql->bindValue(':data', $data['data']);
            $sql->bindValue(':nome', $data['nome']);
            $sql->bindValue(':sobrenome', $data['sobrenome']);
            $sql->bindValue(':area', $data['area']);
            $sql->bindValue(':supervisor', $data['supervisor']);
            $sql->bindValue(':lider', $data['lider']);
            $sql->execute();

            $id = $this->db->lastInsertId();

            if (!$this->getById($id)) {
                return false;
            }

            return true;
        } catch (Exception $e) {
            throw new Exception($e->getMessage());
        }
    }

    public function getResult()
    {
        return $this->result;
    }

    public function error()
    {
        return $this->result['message'];
    }

    private function isValid($data): bool
    {
        if (empty($data['evento'])) {
            $this->result['message']['errors'][] = 'Evento não informado';
        }

        if (empty($data['email'])) {
            $this->result['message']['errors'][] = 'E-mail não informado';
        }

        if (empty($data['nome'])) {
            $this->result['message']['errors'][] = 'Nome não informado';
        }

        if (empty($data['sobrenome'])) {
            $this->result['message']['errors'][] = 'Sobrenome não informado';
        }

        if (empty($data['area'])) {
            $this->result['message']['errors'][] = 'Área não informada';
        }

        if (empty($data['supervisor'])) {
            $this->result['message']['errors'][] = 'Supervisor não informado';
        }

        if (empty($data['lider'])) {
            $this->result['message']['errors'][] = 'Lider não informado';
        }

        if (count($this->result['message']['errors']) == 0) {
            if ($this->getByDataAndEmail(($data['id'] ?? 0), $data['data'], $data['email'])) {
                $this->result['message']['errors'][] = 'Você já possui uma inscricao para esta data';
            }
        }

        $this->result['message']['hasError'] = count($this->result['message']['errors']) > 0;
        return !$this->result['message']['hasError'];
    }
}
